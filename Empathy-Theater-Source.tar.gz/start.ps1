$env:PATH = "C:\Program Files\nodejs;" + $env:PATH
Set-Location "c:\Users\chris\Desktop\EmpathyTheater"
npm run dev
